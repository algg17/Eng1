const quizDiv = document.getElementById('quiz');
const resultDiv = document.getElementById('result');

fetch('data/test1.json')
  .then(res => res.json())
  .then(data => {
    let html = '';
    data.forEach((q, i) => {
      html += `<p><strong>${i + 1}. ${q.question}</strong></p>`;
      q.options.forEach(opt => {
        html += `<label><input type="radio" name="q${i}" value="${opt}"> ${opt}</label><br>`;
      });
    });
    quizDiv.innerHTML = html;

    window.correctAnswers = data.map(q => q.answer); // сохраняем ответы
  });

function checkAnswers() {
  let score = 0;
  window.correctAnswers.forEach((ans, i) => {
    const selected = document.querySelector(\`input[name="q\${i}"]:checked\`);
    if (selected && selected.value === ans) score++;
  });
  resultDiv.innerHTML = `<h3>Your score: ${score} / ${window.correctAnswers.length}</h3>`;
}
